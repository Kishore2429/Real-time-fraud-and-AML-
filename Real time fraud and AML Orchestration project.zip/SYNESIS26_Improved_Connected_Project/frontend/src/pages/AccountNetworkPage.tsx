import React, { useEffect, useState, useCallback, useRef } from 'react';
import { Network, Search, Info, ZoomIn, ZoomOut } from 'lucide-react';
import api from '../services/api';
import type { AccountNode, AccountEdge, AccountRelationshipsResponse } from '../types/api';
import RiskBadge from '../components/RiskBadge';
import { LoadingSkeleton, ErrorState, EmptyState, PageHeader } from '../components/ui';

function normalizeRelationships(raw: unknown): { nodes: AccountNode[]; edges: AccountEdge[] } {
  const r = raw as Record<string, unknown>;
  const nodes: AccountNode[] =
    (r?.nodes as AccountNode[]) ||
    (r?.accounts as AccountNode[]) ||
    [];
  const edges: AccountEdge[] =
    (r?.edges as AccountEdge[]) ||
    (r?.relationships as AccountEdge[]) ||
    (r?.links as AccountEdge[]) ||
    [];

  // Normalize node ids
  return {
    nodes: nodes.map(n => ({ ...n, id: n.id || n.account_id || String(Math.random()) })),
    edges: edges.map(e => ({
      ...e,
      source: e.source || e.source_account || '',
      target: e.target || e.target_account || '',
    })),
  };
}

function getRiskColor(level?: string, score?: number): string {
  const l = (level || '').toLowerCase();
  if (l.includes('high')) return '#ef4444';
  if (l.includes('med')) return '#f59e0b';
  if (l.includes('low')) return '#22c55e';
  if (score !== undefined) {
    if (score >= 60) return '#ef4444';
    if (score >= 30) return '#f59e0b';
    return '#22c55e';
  }
  return '#64748b';
}

// Simple SVG-based force layout (no external lib required)
// Uses a basic spring simulation
interface LayoutNode extends AccountNode {
  x: number;
  y: number;
  vx: number;
  vy: number;
}

function useForceLayout(nodes: AccountNode[], edges: AccountEdge[], width: number, height: number) {
  const [positions, setPositions] = useState<Map<string, { x: number; y: number }>>(new Map());

  useEffect(() => {
    if (nodes.length === 0) return;

    // Initialize positions in a circle
    const layoutNodes: LayoutNode[] = nodes.map((n, i) => {
      const angle = (2 * Math.PI * i) / nodes.length;
      const r = Math.min(width, height) * 0.35;
      return {
        ...n,
        x: width / 2 + r * Math.cos(angle),
        y: height / 2 + r * Math.sin(angle),
        vx: 0, vy: 0,
      };
    });

    const nodeMap = new Map(layoutNodes.map(n => [n.id, n]));

    // Run force iterations
    for (let iter = 0; iter < 200; iter++) {
      // Repulsion
      for (let i = 0; i < layoutNodes.length; i++) {
        for (let j = i + 1; j < layoutNodes.length; j++) {
          const a = layoutNodes[i], b = layoutNodes[j];
          const dx = b.x - a.x, dy = b.y - a.y;
          const dist = Math.sqrt(dx * dx + dy * dy) || 1;
          const force = 2000 / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          a.vx -= fx; a.vy -= fy;
          b.vx += fx; b.vy += fy;
        }
      }

      // Attraction (edges)
      for (const edge of edges) {
        const a = nodeMap.get(edge.source), b = nodeMap.get(edge.target);
        if (!a || !b) continue;
        const dx = b.x - a.x, dy = b.y - a.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const ideal = 120;
        const force = (dist - ideal) * 0.05;
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        a.vx += fx; a.vy += fy;
        b.vx -= fx; b.vy -= fy;
      }

      // Center gravity
      for (const n of layoutNodes) {
        n.vx += (width / 2 - n.x) * 0.01;
        n.vy += (height / 2 - n.y) * 0.01;
      }

      // Apply velocity with damping
      for (const n of layoutNodes) {
        n.vx *= 0.8; n.vy *= 0.8;
        n.x += n.vx; n.y += n.vy;
        n.x = Math.max(40, Math.min(width - 40, n.x));
        n.y = Math.max(40, Math.min(height - 40, n.y));
      }
    }

    const result = new Map<string, { x: number; y: number }>();
    for (const n of layoutNodes) {
      result.set(n.id, { x: n.x, y: n.y });
    }
    setPositions(result);
  }, [nodes, edges, width, height]);

  return positions;
}

export default function AccountNetworkPage() {
  const [graphData, setGraphData] = useState<{ nodes: AccountNode[]; edges: AccountEdge[] } | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedNode, setSelectedNode] = useState<AccountNode | null>(null);
  const [search, setSearch] = useState('');
  const [zoom, setZoom] = useState(1);
  const [dataIsGraph, setDataIsGraph] = useState(false);
  const svgRef = useRef<SVGSVGElement>(null);

  const W = 700, H = 420;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const result = await api.accountRelationships();
    if (result.status === 'ok' && result.data) {
      const normalized = normalizeRelationships(result.data);
      if (normalized.nodes.length > 0) {
        setGraphData(normalized);
        setDataIsGraph(true);
      } else {
        setGraphData(null);
        setDataIsGraph(false);
      }
    } else {
      setError(result.error || 'Failed to load account relationships');
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const positions = useForceLayout(
    graphData?.nodes || [],
    graphData?.edges || [],
    W, H
  );

  const filteredNodes = graphData?.nodes.filter(n => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (n.id || '').toLowerCase().includes(q) ||
      (n.account_id || '').toLowerCase().includes(q) ||
      (n.label || '').toLowerCase().includes(q);
  }) || [];

  return (
    <div className="p-6 space-y-6 slide-in">
      <PageHeader
        title="Account Network"
        subtitle="Transaction relationship graph between accounts"
        icon={<Network size={20} className="text-purple-400" />}
        actions={
          <button
            onClick={load}
            className="px-3 py-1.5 text-sm rounded-lg transition-all"
            style={{ background: 'rgba(139,92,246,0.15)', border: '1px solid rgba(139,92,246,0.3)', color: '#9b4a62' }}
          >
            Refresh
          </button>
        }
      />

      {loading ? (
        <div className="space-y-3"><LoadingSkeleton rows={5} /></div>
      ) : error ? (
        <ErrorState message={error} onRetry={load} />
      ) : !dataIsGraph ? (
        <div className="space-y-4">
          <div
            className="flex items-start gap-3 p-4 rounded-xl"
            style={{ background: 'rgba(139,92,246,0.06)', border: '1px solid rgba(139,92,246,0.2)' }}
          >
            <Info size={16} className="text-purple-400 flex-shrink-0 mt-0.5" />
            <div className="text-sm text-purple-300/80">
              <strong>Note:</strong> The backend did not return graph-compatible data (nodes + edges). 
              The account relationships endpoint may return account records without explicit graph structure.
              Displaying account list view instead.
            </div>
          </div>
          <EmptyState
            icon="🕸️"
            title="Graph Data Unavailable"
            message="The account relationships endpoint returned data that cannot be rendered as a network graph. Check the /api/accounts/relationships response for node and edge fields."
          />
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left: Account list */}
          <div className="glass-card p-4 space-y-3">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Accounts ({graphData!.nodes.length})</h3>
            <div className="relative">
              <Search size={13} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
              <input
                id="network-search"
                type="text"
                placeholder="Search accounts..."
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="w-full pl-8 pr-3 py-1.5 text-xs rounded-lg text-slate-300 placeholder-slate-600 outline-none"
                style={{ background: 'rgba(111,24,50,0.05)', border: '1px solid rgba(111,24,50,0.13)' }}
              />
            </div>
            <div className="space-y-1 max-h-80 overflow-y-auto pr-1">
              {filteredNodes.map(node => (
                <button
                  key={node.id}
                  onClick={() => setSelectedNode(node)}
                  className="w-full text-left px-3 py-2 rounded-lg transition-all text-xs"
                  style={{
                    background: selectedNode?.id === node.id ? 'rgba(139,92,246,0.15)' : 'rgba(111,24,50,0.025)',
                    border: selectedNode?.id === node.id ? '1px solid rgba(139,92,246,0.3)' : '1px solid transparent',
                  }}
                >
                  <div className="flex items-center gap-2">
                    <span
                      className="w-2.5 h-2.5 rounded-full flex-shrink-0"
                      style={{ background: getRiskColor(node.risk_level, node.risk_score) }}
                    />
                    <span className="font-mono text-slate-300 truncate">{node.id}</span>
                  </div>
                  {node.account_type && <p className="text-slate-600 mt-0.5 ml-4">{node.account_type}</p>}
                </button>
              ))}
            </div>
          </div>

          {/* Right: Graph + Detail */}
          <div className="lg:col-span-2 space-y-4">
            {/* Graph canvas */}
            <div
              className="glass-card overflow-hidden relative"
              style={{ height: `${H}px` }}
            >
              {/* Zoom controls */}
              <div className="absolute top-3 right-3 z-10 flex flex-col gap-1">
                <button
                  onClick={() => setZoom(z => Math.min(2, z + 0.2))}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(111,24,50,0.15)' }}
                  aria-label="Zoom in"
                >
                  <ZoomIn size={14} />
                </button>
                <button
                  onClick={() => setZoom(z => Math.max(0.5, z - 0.2))}
                  className="w-7 h-7 rounded-lg flex items-center justify-center text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
                  style={{ background: 'rgba(0,0,0,0.4)', border: '1px solid rgba(111,24,50,0.15)' }}
                  aria-label="Zoom out"
                >
                  <ZoomOut size={14} />
                </button>
              </div>

              <svg
                ref={svgRef}
                width="100%"
                height="100%"
                viewBox={`0 0 ${W} ${H}`}
                style={{ background: 'transparent' }}
              >
                <defs>
                  <marker id="arrowhead" markerWidth="8" markerHeight="6" refX="7" refY="3" orient="auto">
                    <polygon points="0 0, 8 3, 0 6" fill="rgba(100,116,139,0.6)" />
                  </marker>
                </defs>
                <g transform={`scale(${zoom}) translate(${(W * (1 - zoom)) / (2 * zoom)} ${(H * (1 - zoom)) / (2 * zoom)})`}>
                  {/* Edges */}
                  {graphData!.edges.map((edge, i) => {
                    const src = positions.get(edge.source);
                    const tgt = positions.get(edge.target);
                    if (!src || !tgt) return null;
                    return (
                      <line
                        key={i}
                        x1={src.x} y1={src.y}
                        x2={tgt.x} y2={tgt.y}
                        stroke="rgba(100,116,139,0.35)"
                        strokeWidth={1.5}
                        markerEnd="url(#arrowhead)"
                      />
                    );
                  })}
                  {/* Nodes */}
                  {graphData!.nodes.map(node => {
                    const pos = positions.get(node.id);
                    if (!pos) return null;
                    const color = getRiskColor(node.risk_level, node.risk_score);
                    const isSelected = selectedNode?.id === node.id;
                    const label = node.label || node.id || node.account_id || '';
                    const displayLabel = label.length > 10 ? label.slice(0, 10) + '…' : label;

                    return (
                      <g
                        key={node.id}
                        transform={`translate(${pos.x},${pos.y})`}
                        onClick={() => setSelectedNode(node)}
                        style={{ cursor: 'pointer' }}
                      >
                        <circle
                          r={isSelected ? 18 : 14}
                          fill={`${color}22`}
                          stroke={color}
                          strokeWidth={isSelected ? 2.5 : 1.5}
                        />
                        {node.flagged && (
                          <circle r={5} cx={10} cy={-10} fill="#ef4444" stroke="#ffffff" strokeWidth={1.5} />
                        )}
                        <text
                          textAnchor="middle"
                          dy={28}
                          fontSize={9}
                          fill="#94a3b8"
                        >
                          {displayLabel}
                        </text>
                      </g>
                    );
                  })}
                </g>
              </svg>

              {/* Legend */}
              <div
                className="absolute bottom-3 left-3 flex items-center gap-3 px-3 py-2 rounded-lg text-xs"
                style={{ background: 'rgba(6,14,30,0.8)', border: '1px solid rgba(111,24,50,0.13)' }}
              >
                {[{ label: 'High', color: '#ef4444' }, { label: 'Medium', color: '#f59e0b' }, { label: 'Low', color: '#22c55e' }, { label: 'Unknown', color: '#64748b' }].map(({ label, color }) => (
                  <span key={label} className="flex items-center gap-1">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ background: color }} />
                    <span className="text-slate-400">{label}</span>
                  </span>
                ))}
              </div>
            </div>

            {/* Selected node detail */}
            {selectedNode && (
              <div
                className="glass-card p-4 slide-in"
                style={{ borderLeft: `3px solid ${getRiskColor(selectedNode.risk_level, selectedNode.risk_score)}` }}
              >
                <h3 className="text-sm font-semibold text-white mb-3">Account Details</h3>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  {[
                    ['Account ID', selectedNode.id || selectedNode.account_id],
                    ['Type', selectedNode.account_type || '—'],
                    ['Risk Level', ''],
                    ['Risk Score', selectedNode.risk_score?.toString() || '—'],
                    ['Balance', selectedNode.balance ? `₹${selectedNode.balance.toLocaleString('en-IN')}` : '—'],
                    ['Transactions', selectedNode.transaction_count?.toString() || '—'],
                    ['Flagged', selectedNode.flagged ? 'Yes' : 'No'],
                  ].map(([label, value]) => (
                    label === 'Risk Level' ? (
                      <div key={label}>
                        <p className="text-slate-500 mb-1">{label}</p>
                        <RiskBadge level={selectedNode.risk_level || 'unknown'} score={selectedNode.risk_score} />
                      </div>
                    ) : (
                      <div key={label}>
                        <p className="text-slate-500 mb-0.5">{label}</p>
                        <p className="text-slate-200 font-mono">{String(value || '—')}</p>
                      </div>
                    )
                  ))}
                </div>
                <div className="mt-3">
                  <p className="text-xs text-slate-500 mb-1">Connections</p>
                  <p className="text-xs text-slate-300">
                    {graphData!.edges.filter(e => e.source === selectedNode.id || e.target === selectedNode.id).length} transaction relationships
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
