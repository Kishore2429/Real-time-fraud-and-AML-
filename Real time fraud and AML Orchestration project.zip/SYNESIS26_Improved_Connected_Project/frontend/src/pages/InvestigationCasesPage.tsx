import React, { useEffect, useState, useCallback } from 'react';
import { Briefcase, X, Clock, User, Tag, ChevronRight } from 'lucide-react';
import api from '../services/api';
import type { InvestigationCase } from '../types/api';
import RiskBadge from '../components/RiskBadge';
import { LoadingSkeleton, ErrorState, EmptyState, PageHeader } from '../components/ui';

function normalizeCases(raw: unknown): InvestigationCase[] {
  const r = raw as Record<string, unknown>;
  const items = Array.isArray(raw) ? raw : Array.isArray(r?.cases) ? r.cases : Array.isArray(r?.data) ? r.data : [];
  return (items as Record<string, unknown>[]).map((item) => ({
    ...item,
    case_id: String(item.case_id || item.case_number || item.id || '—'),
    severity: String(item.severity || item.risk_level || 'unknown'),
    related_transactions: (item.related_transactions || item.transactions || (item.transaction_id != null ? [String(item.transaction_id)] : [])) as string[],
    description: String(item.description || item.recommended_action || (Array.isArray(item.reasons) ? item.reasons.join(', ') : '') || ''),
  })) as InvestigationCase[];
}

function getCaseId(c: InvestigationCase): string {
  return c.case_id || c.case_number || String(c.id || '—');
}

function getSeverity(c: InvestigationCase): string {
  return c.severity || c.risk_level || 'unknown';
}

function getStatusColor(status?: string): string {
  const s = (status || '').toLowerCase();
  if (s.includes('open') || s.includes('active')) return '#8a2945';
  if (s.includes('closed') || s.includes('resolved')) return '#22c55e';
  if (s.includes('escalat')) return '#ef4444';
  if (s.includes('pending') || s.includes('review')) return '#f59e0b';
  return '#64748b';
}

interface CaseDrawerProps {
  caseItem: InvestigationCase;
  onClose: () => void;
}

function CaseDrawer({ caseItem, onClose }: CaseDrawerProps) {
  const caseId = getCaseId(caseItem);
  const severity = getSeverity(caseItem);
  const transactions = caseItem.related_transactions || caseItem.transactions || [];
  const accounts = caseItem.related_accounts || [];
  const timeline = caseItem.timeline || [];
  const statusColor = getStatusColor(caseItem.status);

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      style={{ background: 'rgba(0,0,0,0.6)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="h-full w-full max-w-md overflow-y-auto slide-in"
        style={{ background: '#ffffff', borderLeft: '1px solid rgba(111,24,50,0.15)' }}
      >
        <div
          className="flex items-center justify-between p-5"
          style={{ borderBottom: '1px solid rgba(111,24,50,0.12)' }}
        >
          <div className="flex items-center gap-2">
            <Briefcase size={18} className="text-amber-400" />
            <span className="font-semibold text-white">Case Detail</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className="p-5 space-y-5">
          <div className="flex items-center justify-between">
            <span className="font-mono text-amber-400 text-sm font-semibold">{caseId}</span>
            <RiskBadge level={severity} size="md" />
          </div>

          {caseItem.title && (
            <div>
              <p className="text-xs text-slate-500 mb-1">Title</p>
              <p className="text-white font-semibold">{caseItem.title}</p>
            </div>
          )}

          {caseItem.description && (
            <div>
              <p className="text-xs text-slate-500 mb-1">Description</p>
              <p className="text-sm text-slate-300">{caseItem.description}</p>
            </div>
          )}

          <div className="grid grid-cols-2 gap-3">
            <div className="rounded-lg p-3" style={{ background: 'rgba(111,24,50,0.035)' }}>
              <p className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Tag size={10} /> Status</p>
              <span className="text-sm font-semibold capitalize" style={{ color: statusColor }}>
                {caseItem.status || 'Unknown'}
              </span>
            </div>
            <div className="rounded-lg p-3" style={{ background: 'rgba(111,24,50,0.035)' }}>
              <p className="text-xs text-slate-500 mb-1 flex items-center gap-1"><User size={10} /> Investigator</p>
              <p className="text-sm text-slate-200">{caseItem.assigned_to || caseItem.investigator || 'Unassigned'}</p>
            </div>
            <div className="rounded-lg p-3" style={{ background: 'rgba(111,24,50,0.035)' }}>
              <p className="text-xs text-slate-500 mb-1 flex items-center gap-1"><Clock size={10} /> Created</p>
              <p className="text-xs text-slate-200">
                {caseItem.created_at ? new Date(caseItem.created_at).toLocaleString('en-IN') : '—'}
              </p>
            </div>
            <div className="rounded-lg p-3" style={{ background: 'rgba(111,24,50,0.035)' }}>
              <p className="text-xs text-slate-500 mb-1">Updated</p>
              <p className="text-xs text-slate-200">
                {caseItem.updated_at ? new Date(caseItem.updated_at).toLocaleString('en-IN') : '—'}
              </p>
            </div>
          </div>

          {transactions.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Related Transactions</p>
              <div className="flex flex-wrap gap-1.5">
                {transactions.map((tx, i) => (
                  <span key={i} className="text-xs font-mono px-2 py-1 rounded" style={{ background: 'rgba(37,99,235,0.1)', color: '#9b4a62', border: '1px solid rgba(37,99,235,0.15)' }}>
                    {tx}
                  </span>
                ))}
              </div>
            </div>
          )}

          {accounts.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Related Accounts</p>
              <div className="flex flex-wrap gap-1.5">
                {accounts.map((acc, i) => (
                  <span key={i} className="text-xs font-mono px-2 py-1 rounded" style={{ background: 'rgba(111,24,50,0.10)', color: '#94a3b8' }}>
                    {acc}
                  </span>
                ))}
              </div>
            </div>
          )}

          {timeline.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-3 uppercase tracking-wider flex items-center gap-1">
                <Clock size={10} /> Timeline
              </p>
              <div className="relative pl-4">
                <div className="absolute left-1.5 top-0 bottom-0 w-px" style={{ background: 'rgba(111,24,50,0.13)' }} />
                {timeline.map((event, i) => (
                  <div key={i} className="relative mb-4 last:mb-0">
                    <div className="absolute -left-2.5 top-1.5 w-2 h-2 rounded-full" style={{ background: '#8a2945' }} />
                    <div>
                      <p className="text-xs text-slate-500">{new Date(event.timestamp).toLocaleString('en-IN')}</p>
                      <p className="text-sm text-slate-300 mt-0.5">{event.event}</p>
                      {event.description && <p className="text-xs text-slate-500 mt-0.5">{event.description}</p>}
                      {event.actor && <p className="text-xs text-slate-600 mt-0.5">by {event.actor}</p>}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {caseItem.tags && caseItem.tags.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-2">Tags</p>
              <div className="flex flex-wrap gap-1.5">
                {caseItem.tags.map((tag, i) => (
                  <span key={i} className="text-xs px-2 py-0.5 rounded-full" style={{ background: 'rgba(139,92,246,0.1)', color: '#9b4a62', border: '1px solid rgba(139,92,246,0.2)' }}>
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

export default function InvestigationCasesPage() {
  const [cases, setCases] = useState<InvestigationCase[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<InvestigationCase | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const result = await api.cases();
    if (result.status === 'ok' && result.data) {
      setCases(normalizeCases(result.data));
    } else {
      setError(result.error || 'Failed to load cases');
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  return (
    <div className="p-6 space-y-6 slide-in">
      <PageHeader
        title="Investigation Cases"
        subtitle="Active and historical fraud investigation cases"
        icon={<Briefcase size={20} className="text-amber-400" />}
        actions={
          <button
            onClick={load}
            className="px-3 py-1.5 text-sm rounded-lg transition-all"
            style={{ background: 'rgba(245,158,11,0.15)', border: '1px solid rgba(245,158,11,0.3)', color: '#fbbf24' }}
          >
            Refresh
          </button>
        }
      />

      {/* Stats banner */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: 'Total Cases', value: cases.length, color: '#8a2945' },
          { label: 'Open', value: cases.filter(c => (c.status || '').toLowerCase().includes('open')).length, color: '#8a2945' },
          { label: 'High Severity', value: cases.filter(c => (c.severity || '').toLowerCase().includes('high')).length, color: '#ef4444' },
          { label: 'Resolved', value: cases.filter(c => (c.status || '').toLowerCase().includes('closed') || (c.status || '').toLowerCase().includes('resolved')).length, color: '#22c55e' },
        ].map(({ label, value, color }) => (
          <div
            key={label}
            className="glass-card p-4 text-center"
            style={{ borderBottom: `2px solid ${color}` }}
          >
            <p className="text-2xl font-bold text-white">{loading && cases.length === 0 ? '—' : value}</p>
            <p className="text-xs text-slate-500 mt-1">{label}</p>
          </div>
        ))}
      </div>

      {loading ? (
        <LoadingSkeleton rows={4} />
      ) : error && cases.length === 0 ? (
        <ErrorState message={error} onRetry={load} />
      ) : cases.length === 0 ? (
        <EmptyState
          icon="📁"
          title="No Investigation Cases"
          message="The backend reports zero open investigation cases. This is accurate data from /api/cases — no active cases exist at this time."
        />
      ) : (
        <div className="space-y-3">
          {cases.map((caseItem, i) => {
            const caseId = getCaseId(caseItem);
            const severity = getSeverity(caseItem);
            const statusColor = getStatusColor(caseItem.status);

            return (
              <div
                key={caseId + i}
                className="glass-card glass-card-hover p-5 cursor-pointer"
                onClick={() => setSelected(caseItem)}
                id={`case-${caseId}`}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <span className="font-mono text-amber-400 text-sm font-semibold">{caseId}</span>
                      <RiskBadge level={severity} />
                      <span
                        className="text-xs px-2 py-0.5 rounded font-medium capitalize"
                        style={{
                          background: `${statusColor}18`,
                          border: `1px solid ${statusColor}35`,
                          color: statusColor,
                        }}
                      >
                        {caseItem.status || 'Unknown'}
                      </span>
                    </div>
                    {caseItem.title && (
                      <p className="text-sm text-slate-200 mb-1.5">{caseItem.title}</p>
                    )}
                    {caseItem.description && (
                      <p className="text-xs text-slate-500 line-clamp-2">{caseItem.description}</p>
                    )}
                    <div className="flex items-center gap-4 mt-2 text-xs text-slate-600">
                      {caseItem.assigned_to && (
                        <span className="flex items-center gap-1"><User size={10} />{caseItem.assigned_to}</span>
                      )}
                      {caseItem.created_at && (
                        <span className="flex items-center gap-1"><Clock size={10} />{new Date(caseItem.created_at).toLocaleDateString('en-IN')}</span>
                      )}
                    </div>
                  </div>
                  <ChevronRight size={16} className="text-slate-600 flex-shrink-0" />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {selected && <CaseDrawer caseItem={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
