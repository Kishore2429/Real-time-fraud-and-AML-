import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { ArrowLeftRight, Search, X, ChevronDown, ChevronUp } from 'lucide-react';
import api from '../services/api';
import type { Transaction } from '../types/api';
import RiskBadge, { getRiskFromScore } from '../components/RiskBadge';
import { LoadingSkeleton, ErrorState, EmptyState, PageHeader } from '../components/ui';

function normalizeTransactions(raw: unknown): Transaction[] {
  if (Array.isArray(raw)) return raw.map((item) => { const tx = item as Transaction; return { ...tx, transaction_ref: tx.transaction_ref || tx.txn_ref, account_id: tx.account_id || tx.sender_account }; });
  const r = raw as Record<string, unknown>;
  if (r?.transactions && Array.isArray(r.transactions)) return normalizeTransactions(r.transactions);
  if (r?.data && Array.isArray(r.data)) return normalizeTransactions(r.data);
  return [];
}

function formatAmount(amount?: number): string {
  if (amount === undefined) return '—';
  return `₹${amount.toLocaleString('en-IN')}`;
}

function getRef(tx: Transaction): string {
  return tx.transaction_ref || tx.txn_ref || tx.reference || String(tx.id || '—');
}

function getAccount(tx: Transaction): string {
  return tx.account_id || tx.account || tx.sender_account || '—';
}

function getTime(tx: Transaction): string {
  const t = tx.timestamp || tx.created_at;
  if (!t) return '—';
  return new Date(t).toLocaleString('en-IN');
}

interface TransactionDrawerProps {
  tx: Transaction;
  onClose: () => void;
}

function TransactionDrawer({ tx, onClose }: TransactionDrawerProps) {
  const score = tx.risk_score ?? 0;
  const risk = tx.risk_level || getRiskFromScore(score);

  const fields: { label: string; value: string }[] = [
    { label: 'Reference', value: getRef(tx) },
    { label: 'Amount', value: formatAmount(tx.amount) },
    { label: 'Account', value: getAccount(tx) },
    { label: 'Receiver', value: tx.receiver_account || '—' },
    { label: 'Type', value: tx.transaction_type || tx.type || '—' },
    { label: 'Currency', value: tx.currency || 'INR' },
    { label: 'Status', value: tx.status || '—' },
    { label: 'Risk Score', value: String(score) },
    { label: 'Timestamp', value: getTime(tx) },
    { label: 'Location', value: tx.location || '—' },
    { label: 'Device', value: tx.device_id || '—' },
    { label: 'IP Address', value: tx.ip_address || '—' },
    { label: 'Merchant', value: tx.merchant || '—' },
  ].filter(f => f.value !== '—' && f.value !== 'undefined');

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      style={{ background: 'rgba(0,0,0,0.6)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="h-full w-full max-w-md overflow-y-auto slide-in"
        style={{ background: '#ffffff', borderLeft: '1px solid rgba(111,24,50,0.15)' }}
      >
        <div
          className="flex items-center justify-between p-5"
          style={{ borderBottom: '1px solid rgba(111,24,50,0.12)' }}
        >
          <div className="flex items-center gap-2">
            <ArrowLeftRight size={18} className="text-blue-400" />
            <span className="font-semibold text-white">Transaction Detail</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className="p-5 space-y-4">
          <div className="flex items-center justify-between">
            <span className="font-mono text-blue-400 text-sm">{getRef(tx)}</span>
            <RiskBadge level={String(risk)} score={score} size="md" />
          </div>
          <div
            className="text-center py-4 rounded-xl"
            style={{ background: 'rgba(37,99,235,0.06)', border: '1px solid rgba(37,99,235,0.15)' }}
          >
            <p className="text-3xl font-bold text-white">{formatAmount(tx.amount)}</p>
            <p className="text-xs text-slate-500 mt-1">{tx.currency || 'INR'} · {tx.transaction_type || tx.type || 'Transfer'}</p>
          </div>
          <div className="grid grid-cols-1 gap-2">
            {fields.map(f => (
              <div
                key={f.label}
                className="flex justify-between items-center py-2 px-3 rounded-lg"
                style={{ background: 'rgba(111,24,50,0.025)' }}
              >
                <span className="text-xs text-slate-500">{f.label}</span>
                <span className="text-xs text-slate-200 font-mono ml-4 text-right break-all max-w-[60%]">{f.value}</span>
              </div>
            ))}
          </div>
          {tx.description && (
            <div>
              <p className="text-xs text-slate-500 mb-1">Description</p>
              <p className="text-sm text-slate-400">{tx.description}</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

type SortKey = 'amount' | 'risk_score' | 'timestamp';
type SortDir = 'asc' | 'desc';

export default function TransactionsPage() {
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [riskFilter, setRiskFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [selected, setSelected] = useState<Transaction | null>(null);
  const [sortKey, setSortKey] = useState<SortKey>('timestamp');
  const [sortDir, setSortDir] = useState<SortDir>('desc');
  const [page, setPage] = useState(0);
  const PAGE_SIZE = 15;

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const result = await api.transactions();
    if (result.status === 'ok' && result.data) {
      setTransactions(normalizeTransactions(result.data));
    } else {
      setError(result.error || 'Failed to load transactions');
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  const toggleSort = (key: SortKey) => {
    if (sortKey === key) setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    else { setSortKey(key); setSortDir('desc'); }
  };

  const filtered = useMemo(() => {
    let list = transactions;
    if (search) {
      const q = search.toLowerCase();
      list = list.filter(tx =>
        getRef(tx).toLowerCase().includes(q) ||
        getAccount(tx).toLowerCase().includes(q) ||
        (tx.merchant || '').toLowerCase().includes(q)
      );
    }
    if (riskFilter !== 'all') {
      list = list.filter(tx => {
        const score = tx.risk_score ?? 0;
        const level = (tx.risk_level || getRiskFromScore(score)).toLowerCase();
        return level.includes(riskFilter);
      });
    }
    return [...list].sort((a, b) => {
      let av: number, bv: number;
      if (sortKey === 'amount') { av = a.amount ?? 0; bv = b.amount ?? 0; }
      else if (sortKey === 'risk_score') { av = a.risk_score ?? 0; bv = b.risk_score ?? 0; }
      else {
        av = new Date(a.timestamp || a.created_at || 0).getTime();
        bv = new Date(b.timestamp || b.created_at || 0).getTime();
      }
      return sortDir === 'asc' ? av - bv : bv - av;
    });
  }, [transactions, search, riskFilter, sortKey, sortDir]);

  const paginated = filtered.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE);
  const totalPages = Math.ceil(filtered.length / PAGE_SIZE);

  const SortIcon = ({ col }: { col: SortKey }) => (
    sortKey === col
      ? sortDir === 'asc' ? <ChevronUp size={12} /> : <ChevronDown size={12} />
      : <ChevronDown size={12} className="opacity-30" />
  );

  return (
    <div className="p-6 space-y-6 slide-in">
      <PageHeader
        title="Transactions"
        subtitle={`${filtered.length} of ${transactions.length} transactions`}
        icon={<ArrowLeftRight size={20} className="text-blue-400" />}
        actions={
          <button
            onClick={load}
            className="px-3 py-1.5 text-sm rounded-lg transition-all"
            style={{ background: 'rgba(37,99,235,0.15)', border: '1px solid rgba(37,99,235,0.3)', color: '#9b4a62' }}
          >
            Refresh
          </button>
        }
      />

      {/* Filters */}
      <div className="flex flex-wrap gap-3">
        <div className="relative">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            id="tx-search"
            type="text"
            placeholder="Search by reference or account..."
            value={search}
            onChange={e => { setSearch(e.target.value); setPage(0); }}
            className="pl-9 pr-4 py-2 text-sm rounded-lg text-slate-300 placeholder-slate-600 outline-none w-64"
            style={{ background: 'rgba(111,24,50,0.05)', border: '1px solid rgba(111,24,50,0.13)' }}
          />
        </div>
        <div className="flex gap-2">
          {(['all', 'high', 'medium', 'low'] as const).map(f => (
            <button
              key={f}
              id={`tx-filter-${f}`}
              onClick={() => { setRiskFilter(f); setPage(0); }}
              className="px-3 py-2 rounded-lg text-xs font-medium transition-all"
              style={{
                background: riskFilter === f ? 'rgba(37,99,235,0.2)' : 'rgba(111,24,50,0.05)',
                border: riskFilter === f ? '1px solid rgba(37,99,235,0.4)' : '1px solid rgba(111,24,50,0.13)',
                color: riskFilter === f ? '#9b4a62' : '#94a3b8',
              }}
            >
              {f.charAt(0).toUpperCase() + f.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="glass-card overflow-hidden">
        {loading ? (
          <div className="p-5"><LoadingSkeleton rows={6} /></div>
        ) : error && transactions.length === 0 ? (
          <ErrorState message={error} onRetry={load} />
        ) : filtered.length === 0 ? (
          <EmptyState
            icon="🔍"
            title="No transactions found"
            message="Try adjusting your search or filter criteria."
          />
        ) : (
          <>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr style={{ borderBottom: '1px solid rgba(111,24,50,0.10)', background: 'rgba(255,255,255,0.02)' }}>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Reference</th>
                    <th
                      className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer select-none"
                      onClick={() => toggleSort('amount')}
                    >
                      <span className="flex items-center gap-1">Amount <SortIcon col="amount" /></span>
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Account</th>
                    <th
                      className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer select-none"
                      onClick={() => toggleSort('timestamp')}
                    >
                      <span className="flex items-center gap-1">Time <SortIcon col="timestamp" /></span>
                    </th>
                    <th
                      className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider cursor-pointer select-none"
                      onClick={() => toggleSort('risk_score')}
                    >
                      <span className="flex items-center gap-1">Risk <SortIcon col="risk_score" /></span>
                    </th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-slate-500 uppercase tracking-wider">Status</th>
                  </tr>
                </thead>
                <tbody>
                  {paginated.map((tx, i) => {
                    const score = tx.risk_score ?? 0;
                    const risk = tx.risk_level || getRiskFromScore(score);
                    return (
                      <tr
                        key={getRef(tx) + i}
                        className="table-row-hover"
                        onClick={() => setSelected(tx)}
                        style={{ borderBottom: '1px solid rgba(111,24,50,0.035)' }}
                      >
                        <td className="px-4 py-3 font-mono text-blue-400 text-xs">{getRef(tx)}</td>
                        <td className="px-4 py-3 text-white font-semibold">{formatAmount(tx.amount)}</td>
                        <td className="px-4 py-3 text-slate-400 font-mono text-xs">{getAccount(tx)}</td>
                        <td className="px-4 py-3 text-slate-500 text-xs">{getTime(tx)}</td>
                        <td className="px-4 py-3">
                          <RiskBadge level={String(risk)} score={score} />
                        </td>
                        <td className="px-4 py-3">
                          <span className="text-xs text-slate-400 capitalize">{tx.status || 'completed'}</span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {/* Pagination */}
            {totalPages > 1 && (
              <div
                className="flex items-center justify-between px-4 py-3"
                style={{ borderTop: '1px solid rgba(111,24,50,0.10)' }}
              >
                <span className="text-xs text-slate-500">
                  Showing {page * PAGE_SIZE + 1}–{Math.min((page + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
                </span>
                <div className="flex gap-2">
                  <button
                    onClick={() => setPage(p => Math.max(0, p - 1))}
                    disabled={page === 0}
                    className="px-3 py-1 text-xs rounded-lg transition-all disabled:opacity-40"
                    style={{ background: 'rgba(111,24,50,0.05)', border: '1px solid rgba(111,24,50,0.13)', color: '#94a3b8' }}
                  >
                    Previous
                  </button>
                  <button
                    onClick={() => setPage(p => Math.min(totalPages - 1, p + 1))}
                    disabled={page >= totalPages - 1}
                    className="px-3 py-1 text-xs rounded-lg transition-all disabled:opacity-40"
                    style={{ background: 'rgba(111,24,50,0.05)', border: '1px solid rgba(111,24,50,0.13)', color: '#94a3b8' }}
                  >
                    Next
                  </button>
                </div>
              </div>
            )}
          </>
        )}
      </div>

      {selected && <TransactionDrawer tx={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
