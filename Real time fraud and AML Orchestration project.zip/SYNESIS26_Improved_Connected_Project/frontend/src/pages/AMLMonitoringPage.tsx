import React, { useEffect, useState, useCallback } from 'react';
import { BarChart3, AlertTriangle, ChevronRight, X } from 'lucide-react';
import api from '../services/api';
import type { AMLPattern } from '../types/api';
import RiskBadge from '../components/RiskBadge';
import { LoadingSkeleton, ErrorState, EmptyState, PageHeader } from '../components/ui';

function normalizePatterns(raw: unknown): AMLPattern[] {
  const r = raw as Record<string, unknown>;
  const items = Array.isArray(raw) ? raw : Array.isArray(r?.patterns) ? r.patterns : Array.isArray(r?.data) ? r.data : [];
  return (items as Record<string, unknown>[]).map((item, index) => ({
    ...item,
    id: item.id ?? `AML-${index + 1}`,
    pattern_type: String(item.pattern_type || item.type || item.pattern || 'Unknown Pattern'),
    related_transactions: (item.related_transactions || item.transaction_refs || item.transactions || []) as string[],
    related_accounts: (item.related_accounts || item.accounts || (item.account ? [item.account] : [])) as string[],
    explanation: String(item.explanation || item.description || 'Flagged by a prototype AML heuristic; review context before making a decision.'),
    severity: String(item.severity || item.risk_level || 'medium'),
  })) as AMLPattern[];
}

function getPatternType(p: AMLPattern): string {
  return p.pattern_type || p.type || 'Unknown Pattern';
}

function getSeverity(p: AMLPattern): string {
  return p.severity || p.risk_level || 'unknown';
}

interface PatternDrawerProps {
  pattern: AMLPattern;
  onClose: () => void;
}

function PatternDrawer({ pattern, onClose }: PatternDrawerProps) {
  const accounts = pattern.accounts || pattern.related_accounts || [];
  const transactions = pattern.transactions || pattern.related_transactions || [];
  const indicators = pattern.indicators || [];

  return (
    <div
      className="fixed inset-0 z-50 flex justify-end"
      style={{ background: 'rgba(0,0,0,0.6)' }}
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        className="h-full w-full max-w-md overflow-y-auto slide-in"
        style={{ background: '#ffffff', borderLeft: '1px solid rgba(111,24,50,0.15)' }}
      >
        <div
          className="flex items-center justify-between p-5"
          style={{ borderBottom: '1px solid rgba(111,24,50,0.12)' }}
        >
          <div className="flex items-center gap-2">
            <BarChart3 size={18} className="text-cyan-400" />
            <span className="font-semibold text-white">AML Pattern Detail</span>
          </div>
          <button onClick={onClose} className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-white/5" aria-label="Close">
            <X size={18} />
          </button>
        </div>
        <div className="p-5 space-y-5">
          <div className="flex items-center justify-between">
            <span className="font-mono text-cyan-400 text-sm">{pattern.pattern_id || pattern.id || '—'}</span>
            <RiskBadge level={getSeverity(pattern)} size="md" />
          </div>

          <div>
            <p className="text-xs text-slate-500 mb-1">Pattern Type</p>
            <p className="text-white font-semibold">{getPatternType(pattern)}</p>
          </div>

          {pattern.description && (
            <div>
              <p className="text-xs text-slate-500 mb-1">Description</p>
              <p className="text-sm text-slate-300">{pattern.description}</p>
            </div>
          )}

          {pattern.explanation && (
            <div className="rounded-lg p-4" style={{ background: 'rgba(6,182,212,0.06)', border: '1px solid rgba(6,182,212,0.15)' }}>
              <p className="text-xs text-cyan-500 mb-1 font-semibold uppercase tracking-wider">Why Flagged</p>
              <p className="text-sm text-slate-300">{pattern.explanation}</p>
            </div>
          )}

          {indicators.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Indicators</p>
              <div className="space-y-1.5">
                {indicators.map((ind, i) => (
                  <div key={i} className="flex items-start gap-2 text-sm">
                    <span className="text-amber-400 mt-0.5">⚑</span>
                    <span className="text-slate-300">{ind}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {accounts.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Related Accounts</p>
              <div className="flex flex-wrap gap-2">
                {accounts.map((acc, i) => (
                  <span key={i} className="text-xs font-mono px-2 py-1 rounded" style={{ background: 'rgba(111,24,50,0.10)', color: '#94a3b8' }}>
                    {acc}
                  </span>
                ))}
              </div>
            </div>
          )}

          {transactions.length > 0 && (
            <div>
              <p className="text-xs text-slate-500 mb-2 uppercase tracking-wider">Related Transactions</p>
              <div className="flex flex-wrap gap-2">
                {transactions.map((tx, i) => (
                  <span key={i} className="text-xs font-mono px-2 py-1 rounded" style={{ background: 'rgba(111,24,50,0.10)', color: '#9b4a62' }}>
                    {tx}
                  </span>
                ))}
              </div>
            </div>
          )}

          {pattern.amount !== undefined && (
            <div>
              <p className="text-xs text-slate-500 mb-1">Total Amount Involved</p>
              <p className="text-white font-semibold">₹{pattern.amount.toLocaleString('en-IN')}</p>
            </div>
          )}

          {pattern.confidence !== undefined && (
            <div>
              <p className="text-xs text-slate-500 mb-2">Detection Confidence</p>
              <div className="h-2 rounded-full" style={{ background: 'rgba(111,24,50,0.13)' }}>
                <div
                  className="h-2 rounded-full transition-all"
                  style={{
                    width: `${Math.min(100, pattern.confidence * 100)}%`,
                    background: 'linear-gradient(90deg, #a65b70, #8a2945)',
                  }}
                />
              </div>
              <p className="text-xs text-slate-500 mt-1">{(pattern.confidence * 100).toFixed(0)}%</p>
            </div>
          )}

          {/* Legal disclaimer */}
          <div
            className="rounded-lg p-3 text-xs"
            style={{ background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.15)' }}
          >
            <AlertTriangle size={12} className="text-amber-400 inline mr-1" />
            <span className="text-amber-400/80">
              These are <strong>indicators requiring investigation</strong>, not proof of money laundering. 
              Escalate to a compliance officer before any action.
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

const PATTERN_ICONS: Record<string, string> = {
  structuring: '🔢',
  circular: '🔄',
  layering: '📊',
  smurfing: '🔀',
  default: '⚠️',
};

export default function AMLMonitoringPage() {
  const [patterns, setPatterns] = useState<AMLPattern[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<AMLPattern | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);
    const result = await api.amlPatterns();
    if (result.status === 'ok' && result.data) {
      setPatterns(normalizePatterns(result.data));
    } else {
      setError(result.error || 'Failed to load AML patterns');
    }
    setLoading(false);
  }, []);

  useEffect(() => { load(); }, [load]);

  function getIcon(p: AMLPattern): string {
    const t = getPatternType(p).toLowerCase();
    for (const [key, icon] of Object.entries(PATTERN_ICONS)) {
      if (t.includes(key)) return icon;
    }
    return PATTERN_ICONS.default;
  }

  return (
    <div className="p-6 space-y-6 slide-in">
      <PageHeader
        title="AML Monitoring"
        subtitle="Anti-money laundering pattern detection indicators"
        icon={<BarChart3 size={20} className="text-cyan-400" />}
        actions={
          <button
            onClick={load}
            className="px-3 py-1.5 text-sm rounded-lg transition-all"
            style={{ background: 'rgba(6,182,212,0.15)', border: '1px solid rgba(6,182,212,0.3)', color: '#a65b70' }}
          >
            Refresh
          </button>
        }
      />

      {/* Disclaimer banner */}
      <div
        className="flex items-start gap-3 p-4 rounded-xl"
        style={{ background: 'rgba(245,158,11,0.06)', border: '1px solid rgba(245,158,11,0.2)' }}
      >
        <AlertTriangle size={18} className="text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="text-sm text-amber-400/80">
          <strong className="text-amber-400">Investigation Required:</strong> The indicators below are algorithmically detected patterns 
          that may warrant further investigation. They are <em>not</em> proof of money laundering. Refer to your 
          compliance team before escalation.
        </div>
      </div>

      {loading ? (
        <div className="space-y-3"><LoadingSkeleton rows={4} /></div>
      ) : error && patterns.length === 0 ? (
        <ErrorState
          title="Unable to Load AML Data"
          message={error}
          onRetry={load}
        />
      ) : patterns.length === 0 ? (
        <EmptyState
          icon="✅"
          title="No AML Patterns Detected"
          message="No suspicious patterns were identified in the current dataset. This may mean clean data or insufficient transaction volume for pattern detection."
        />
      ) : (
        <div className="space-y-3">
          {patterns.map((pattern, i) => {
            const id = pattern.pattern_id || pattern.id || `PATTERN-${i}`;
            const severity = getSeverity(pattern);
            const type = getPatternType(pattern);
            const accounts = pattern.accounts || pattern.related_accounts || [];

            return (
              <div
                key={String(id)}
                className="glass-card glass-card-hover p-5 cursor-pointer"
                onClick={() => setSelected(pattern)}
                id={`pattern-${String(id)}`}
              >
                <div className="flex items-start gap-4">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center text-lg flex-shrink-0"
                    style={{ background: 'rgba(6,182,212,0.1)', border: '1px solid rgba(6,182,212,0.2)' }}
                  >
                    {getIcon(pattern)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-1.5">
                      <span className="font-semibold text-white text-sm">{type}</span>
                      <RiskBadge level={severity} />
                    </div>
                    {pattern.description && (
                      <p className="text-xs text-slate-500 mb-2 line-clamp-2">{pattern.description}</p>
                    )}
                    {accounts.length > 0 && (
                      <div className="flex flex-wrap gap-1.5">
                        {accounts.slice(0, 4).map((acc, ai) => (
                          <span
                            key={ai}
                            className="text-xs font-mono px-2 py-0.5 rounded"
                            style={{ background: 'rgba(111,24,50,0.05)', color: '#94a3b8' }}
                          >
                            {acc}
                          </span>
                        ))}
                        {accounts.length > 4 && (
                          <span className="text-xs text-slate-600">+{accounts.length - 4} more</span>
                        )}
                      </div>
                    )}
                    {pattern.amount !== undefined && (
                      <p className="text-xs text-slate-500 mt-2">
                        Total involved: <span className="text-white font-semibold">₹{pattern.amount.toLocaleString('en-IN')}</span>
                      </p>
                    )}
                  </div>
                  <ChevronRight size={16} className="text-slate-600 flex-shrink-0" />
                </div>
              </div>
            );
          })}
        </div>
      )}

      {selected && <PatternDrawer pattern={selected} onClose={() => setSelected(null)} />}
    </div>
  );
}
