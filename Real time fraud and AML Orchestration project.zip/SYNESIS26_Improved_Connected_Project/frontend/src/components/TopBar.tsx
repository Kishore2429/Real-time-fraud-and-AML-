import React, { useState } from 'react';
import { Search, Bell, User } from 'lucide-react';

interface TopBarProps {
  sidebarCollapsed: boolean;
}

export default function TopBar({ sidebarCollapsed }: TopBarProps) {
  const [searchValue, setSearchValue] = useState('');
  const now = new Date();
  const timeStr = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
  const dateStr = now.toLocaleDateString('en-IN', { day: '2-digit', month: 'short', year: 'numeric' });

  return (
    <header
      className="flex items-center gap-4 px-6 h-16 flex-shrink-0"
      style={{
        background: 'rgba(255,255,255,0.96)',
        borderBottom: '1px solid rgba(111,24,50,0.10)',
        backdropFilter: 'blur(8px)',
      }}
    >
      {/* Search bar */}
      <div className="flex-1 max-w-md relative">
        <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
        <input
          id="global-search"
          type="text"
          placeholder="Search transactions, alerts, accounts..."
          value={searchValue}
          onChange={(e) => setSearchValue(e.target.value)}
          className="w-full pl-9 pr-4 py-2 text-sm rounded-lg text-slate-300 placeholder-slate-600 outline-none transition-all"
          style={{
            background: 'rgba(111,24,50,0.05)',
            border: '1px solid rgba(111,24,50,0.13)',
          }}
          onFocus={(e) => { e.target.style.borderColor = 'rgba(59,130,246,0.5)'; }}
          onBlur={(e) => { e.target.style.borderColor = 'rgba(111,24,50,0.13)'; }}
        />
      </div>

      <div className="flex-1" />

      {/* Date/time */}
      <div className="hidden md:flex flex-col items-end text-xs">
        <span className="text-slate-300 font-mono">{timeStr}</span>
        <span className="text-slate-600">{dateStr}</span>
      </div>

      {/* Notifications */}
      <button
        id="notifications-btn"
        className="relative p-2 rounded-lg text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
        aria-label="Notifications"
      >
        <Bell size={18} />
        <span
          className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
          style={{ background: '#ef4444' }}
        />
      </button>

      {/* User */}
      <button
        id="user-menu-btn"
        className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-sm text-slate-400 hover:text-white hover:bg-white/5 transition-colors"
        aria-label="User menu"
      >
        <div
          className="w-7 h-7 rounded-full flex items-center justify-center text-xs font-semibold"
          style={{ background: 'linear-gradient(135deg, #6f1832, #5b1830)' }}
        >
          <User size={14} className="text-white" />
        </div>
        <span className="hidden md:block font-medium text-slate-300">Analyst</span>
      </button>
    </header>
  );
}
