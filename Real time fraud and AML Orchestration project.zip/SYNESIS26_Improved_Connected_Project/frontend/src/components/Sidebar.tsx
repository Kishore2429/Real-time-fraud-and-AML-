import React, { useState, useEffect } from 'react';
import { NavLink, useLocation } from 'react-router-dom';
import {
  LayoutDashboard,
  ArrowLeftRight,
  ShieldAlert,
  BarChart3,
  Network,
  Briefcase,
  ChevronLeft,
  ChevronRight,
  Wifi,
  WifiOff,
  Zap,
} from 'lucide-react';
import api from '../services/api';

interface NavItem {
  path: string;
  label: string;
  icon: React.ReactNode;
}

const navItems: NavItem[] = [
  { path: '/', label: 'Overview', icon: <LayoutDashboard size={18} /> },
  { path: '/transactions', label: 'Transactions', icon: <ArrowLeftRight size={18} /> },
  { path: '/fraud-alerts', label: 'Fraud Alerts', icon: <ShieldAlert size={18} /> },
  { path: '/aml', label: 'AML Monitoring', icon: <BarChart3 size={18} /> },
  { path: '/network', label: 'Account Network', icon: <Network size={18} /> },
  { path: '/cases', label: 'Investigation Cases', icon: <Briefcase size={18} /> },
];

interface SidebarProps {
  collapsed: boolean;
  setCollapsed: (v: boolean) => void;
}

export default function Sidebar({ collapsed, setCollapsed }: SidebarProps) {
  const location = useLocation();
  const [connected, setConnected] = useState<boolean | null>(null);

  useEffect(() => {
    const checkHealth = async () => {
      const result = await api.health();
      setConnected(result.status === 'ok');
    };
    checkHealth();
    const interval = setInterval(checkHealth, 30000);
    return () => clearInterval(interval);
  }, []);

  return (
    <aside
      className="flex flex-col h-full transition-all duration-300 relative"
      style={{
        width: collapsed ? '64px' : '220px',
        background: 'linear-gradient(180deg, #ffffff 0%, #ffffff 100%)',
        borderRight: '1px solid rgba(111,24,50,0.10)',
        minHeight: '100vh',
      }}
    >
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-5" style={{ minHeight: '72px' }}>
        <div
          className="flex-shrink-0 flex items-center justify-center rounded-lg"
          style={{
            width: '36px', height: '36px',
            background: 'linear-gradient(135deg, #6f1832, #5b1830)',
            boxShadow: '0 0 16px rgba(37,99,235,0.4)',
          }}
        >
          <Zap size={20} style={{ color: "#ffffff" }} />
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <div className="font-bold text-white text-sm leading-tight tracking-wide">SYNESIS 26</div>
            <div className="text-xs mt-0.5" style={{ color: '#9b4a62', letterSpacing: '0.08em' }}>
              FRAUD &amp; AML
            </div>
          </div>
        )}
      </div>

      {/* DEMO label */}
      {!collapsed && (
        <div className="mx-3 mb-4">
          <div
            className="text-center py-1 rounded text-xs font-semibold tracking-widest"
            style={{
              background: 'rgba(245,158,11,0.12)',
              border: '1px solid rgba(245,158,11,0.3)',
              color: '#f59e0b',
            }}
          >
            DEMO ENV
          </div>
        </div>
      )}

      {/* Navigation */}
      <nav className="flex-1 px-2 space-y-1">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <NavLink
              key={item.path}
              to={item.path}
              title={collapsed ? item.label : undefined}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-all duration-150 group ${
                isActive ? 'nav-active' : 'text-slate-400 hover:text-white hover:bg-white/5'
              }`}
              style={isActive ? { borderLeft: '2px solid #8a2945' } : { borderLeft: '2px solid transparent' }}
            >
              <span className={`flex-shrink-0 ${isActive ? 'text-blue-400' : 'text-slate-500 group-hover:text-slate-300'}`}>
                {item.icon}
              </span>
              {!collapsed && <span className="truncate">{item.label}</span>}
            </NavLink>
          );
        })}
      </nav>

      {/* Connection status */}
      <div className="p-3">
        {!collapsed ? (
          <div
            className="flex items-center gap-2 px-3 py-2 rounded-lg text-xs"
            style={{ background: 'rgba(111,24,50,0.035)', border: '1px solid rgba(111,24,50,0.10)' }}
          >
            {connected === null ? (
              <><span className="w-2 h-2 rounded-full bg-amber-400 pulse-dot" /><span className="text-amber-400">Checking...</span></>
            ) : connected ? (
              <><Wifi size={12} className="text-green-400" /><span className="text-green-400">Backend Connected</span></>
            ) : (
              <><WifiOff size={12} className="text-red-400" /><span className="text-red-400">Disconnected</span></>
            )}
          </div>
        ) : (
          <div className="flex justify-center">
            {connected ? (
              <Wifi size={16} className="text-green-400" />
            ) : connected === false ? (
              <WifiOff size={16} className="text-red-400" />
            ) : (
              <div className="w-2 h-2 rounded-full bg-amber-400 pulse-dot" />
            )}
          </div>
        )}
      </div>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-20 w-6 h-6 rounded-full flex items-center justify-center text-slate-400 hover:text-white transition-colors"
        style={{
          background: '#f4eaed',
          border: '1px solid rgba(111,24,50,0.18)',
          zIndex: 10,
        }}
        aria-label={collapsed ? 'Expand sidebar' : 'Collapse sidebar'}
      >
        {collapsed ? <ChevronRight size={12} /> : <ChevronLeft size={12} />}
      </button>
    </aside>
  );
}
