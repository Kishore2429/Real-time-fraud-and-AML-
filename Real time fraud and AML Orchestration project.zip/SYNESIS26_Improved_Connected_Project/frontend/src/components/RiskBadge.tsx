import React from 'react';

interface RiskBadgeProps {
  level: string;
  score?: number;
  size?: 'sm' | 'md';
}

export function getRiskLevel(level: string = ''): 'high' | 'medium' | 'low' | 'unknown' {
  const l = level.toLowerCase();
  if (l.includes('high') || l.includes('critical')) return 'high';
  if (l.includes('med')) return 'medium';
  if (l.includes('low')) return 'low';
  return 'unknown';
}

export function getRiskFromScore(score: number): 'high' | 'medium' | 'low' {
  if (score >= 60) return 'high';
  if (score >= 30) return 'medium';
  return 'low';
}

const riskConfig = {
  high: {
    bg: 'rgba(239,68,68,0.12)',
    border: 'rgba(239,68,68,0.3)',
    text: '#ef4444',
    label: 'HIGH',
  },
  medium: {
    bg: 'rgba(245,158,11,0.12)',
    border: 'rgba(245,158,11,0.3)',
    text: '#f59e0b',
    label: 'MEDIUM',
  },
  low: {
    bg: 'rgba(34,197,94,0.12)',
    border: 'rgba(34,197,94,0.3)',
    text: '#22c55e',
    label: 'LOW',
  },
  unknown: {
    bg: 'rgba(100,116,139,0.12)',
    border: 'rgba(100,116,139,0.3)',
    text: '#94a3b8',
    label: 'UNKNOWN',
  },
};

export default function RiskBadge({ level, score, size = 'sm' }: RiskBadgeProps) {
  const risk = getRiskLevel(level);
  const cfg = riskConfig[risk];
  const padding = size === 'md' ? '4px 12px' : '2px 8px';
  const fontSize = size === 'md' ? '0.75rem' : '0.7rem';

  return (
    <span
      style={{
        background: cfg.bg,
        border: `1px solid ${cfg.border}`,
        color: cfg.text,
        padding,
        borderRadius: '4px',
        fontSize,
        fontWeight: 600,
        letterSpacing: '0.08em',
        display: 'inline-flex',
        alignItems: 'center',
        gap: '4px',
      }}
    >
      <span
        style={{
          width: '6px', height: '6px', borderRadius: '50%',
          background: cfg.text, display: 'inline-block', flexShrink: 0,
        }}
      />
      {cfg.label}
      {score !== undefined && ` • ${score}`}
    </span>
  );
}
