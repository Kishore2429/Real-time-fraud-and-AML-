@echo off
if not exist .venv\Scripts\python.exe (
  echo First run setup.bat to install dependencies.
  pause
  exit /b 1
)
.venv\Scripts\python.exe -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
